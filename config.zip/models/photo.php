<?php
// config/database.php - Koneksi database
$host = 'localhost';
$dbname = 'photobook_db';
$username = 'root';
$password = '';

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit;
}

// models/User.php - Model untuk pengguna
class User {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function register($username, $email, $password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (username, email, password, created_at) VALUES (:username, :email, :password, NOW())";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashed_password);
        
        return $stmt->execute();
    }
    
    public function login($email, $password) {
        $query = "SELECT * FROM users WHERE email = :email";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        
        return false;
    }
}

// models/PhotoBook.php - Model untuk photobook
class PhotoBook {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function create($user_id, $title, $description, $cover_image) {
        $query = "INSERT INTO photobooks (user_id, title, description, cover_image, created_at) 
                 VALUES (:user_id, :title, :description, :cover_image, NOW())";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':cover_image', $cover_image);
        
        if ($stmt->execute()) {
            return $this->db->lastInsertId();
        }
        
        return false;
    }
    
    public function getAll($user_id) {
        $query = "SELECT * FROM photobooks WHERE user_id = :user_id ORDER BY created_at DESC";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getById($id, $user_id) {
        $query = "SELECT * FROM photobooks WHERE id = :id AND user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function update($id, $user_id, $title, $description, $cover_image = null) {
        $cover_set = "";
        if ($cover_image) {
            $cover_set = ", cover_image = :cover_image";
        }
        
        $query = "UPDATE photobooks SET title = :title, description = :description" . $cover_set . " 
                 WHERE id = :id AND user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        
        if ($cover_image) {
            $stmt->bindParam(':cover_image', $cover_image);
        }
        
        return $stmt->execute();
    }
    
    public function delete($id, $user_id) {
        // First delete all photos associated with this photobook
        $query = "DELETE FROM photos WHERE photobook_id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        // Then delete the photobook
        $query = "DELETE FROM photobooks WHERE id = :id AND user_id = :user_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':user_id', $user_id);
        
        return $stmt->execute();
    }
}

// models/Photo.php - Model untuk foto dalam photobook
class Photo {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function upload($photobook_id, $file_path, $caption, $frame_id = null) {
        $query = "INSERT INTO photos (photobook_id, file_path, caption, frame_id, uploaded_at) 
                 VALUES (:photobook_id, :file_path, :caption, :frame_id, NOW())";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':photobook_id', $photobook_id);
        $stmt->bindParam(':file_path', $file_path);
        $stmt->bindParam(':caption', $caption);
        $stmt->bindParam(':frame_id', $frame_id);
        
        return $stmt->execute();
    }
    
    public function getByPhotoBookId($photobook_id) {
        $query = "SELECT p.*, f.file_path as frame_path FROM photos p 
                 LEFT JOIN frames f ON p.frame_id = f.id 
                 WHERE p.photobook_id = :photobook_id 
                 ORDER BY p.id ASC";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':photobook_id', $photobook_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function updateFrame($photo_id, $frame_id) {
        $query = "UPDATE photos SET frame_id = :frame_id WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $photo_id);
        $stmt->bindParam(':frame_id', $frame_id);
        
        return $stmt->execute();
    }
    
    public function updateCaption($photo_id, $caption) {
        $query = "UPDATE photos SET caption = :caption WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $photo_id);
        $stmt->bindParam(':caption', $caption);
        
        return $stmt->execute();
    }
    
    public function delete($photo_id) {
        // Get file path before deleting
        $query = "SELECT file_path FROM photos WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $photo_id);
        $stmt->execute();
        $photo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Delete from database
        $query = "DELETE FROM photos WHERE id = :id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $photo_id);
        $result = $stmt->execute();
        
        // Delete file from server
        if ($result && file_exists($photo['file_path'])) {
            unlink($photo['file_path']);
        }
        
        return $result;
    }
}

// models/Frame.php - Model untuk frame foto
class Frame {
    private $db;
    
    public function __construct($db) {
        $this->db = $db;
    }
    
    public function getAllFrames() {
        $query = "SELECT * FROM frames ORDER BY category";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getFramesByCategory($category) {
        $query = "SELECT * FROM frames WHERE category = :category";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':category', $category);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// utils/image_processor.php - Utilitas untuk memproses gambar
class ImageProcessor {
    public static function resize($file_path, $width, $height) {
        $image_info = getimagesize($file_path);
        $image_type = $image_info[2];
        
        if ($image_type == IMAGETYPE_JPEG) {
            $image = imagecreatefromjpeg($file_path);
        } elseif ($image_type == IMAGETYPE_GIF) {
            $image = imagecreatefromgif($file_path);
        } elseif ($image_type == IMAGETYPE_PNG) {
            $image = imagecreatefrompng($file_path);
        } else {
            return false;
        }
        
        $new_image = imagecreatetruecolor($width, $height);
        imagecopyresampled($new_image, $image, 0, 0, 0, 0, $width, $height, imagesx($image), imagesy($image));
        
        $file_info = pathinfo($file_path);
        $new_file_path = $file_info['dirname'] . '/' . $file_info['filename'] . '_' . $width . 'x' . $height . '.' . $file_info['extension'];
        
        if ($image_type == IMAGETYPE_JPEG) {
            imagejpeg($new_image, $new_file_path, 90);
        } elseif ($image_type == IMAGETYPE_GIF) {
            imagegif($new_image, $new_file_path);
        } elseif ($image_type == IMAGETYPE_PNG) {
            imagepng($new_image, $new_file_path, 9);
        }
        
        imagedestroy($image);
        imagedestroy($new_image);
        
        return $new_file_path;
    }
    
    public static function applyFrame($photo_path, $frame_path) {
        $photo = imagecreatefromjpeg($photo_path);
        $frame = imagecreatefrompng($frame_path);
        
        $photo_width = imagesx($photo);
        $photo_height = imagesy($photo);
        
        $frame = imagescale($frame, $photo_width, $photo_height);
        
        // Create a new image with the same dimensions
        $result = imagecreatetruecolor($photo_width, $photo_height);
        
        // Copy the photo to the result
        imagecopy($result, $photo, 0, 0, 0, 0, $photo_width, $photo_height);
        
        // Overlay the frame
        imagecopy($result, $frame, 0, 0, 0, 0, $photo_width, $photo_height);
        
        // Save the result
        $file_info = pathinfo($photo_path);
        $new_file_path = $file_info['dirname'] . '/' . $file_info['filename'] . '_framed.' . $file_info['extension'];
        imagejpeg($result, $new_file_path, 90);
        
        imagedestroy($photo);
        imagedestroy($frame);
        imagedestroy($result);
        
        return $new_file_path;
    }
    
    public static function applyFilter($photo_path, $filter_type, $value = 50) {
        $image = imagecreatefromjpeg($photo_path);
        
        switch ($filter_type) {
            case 'brightness':
                imagefilter($image, IMG_FILTER_BRIGHTNESS, $value - 50);
                break;
            case 'contrast':
                imagefilter($image, IMG_FILTER_CONTRAST, 50 - $value);
                break;
            case 'saturation':
                // Saturation is simulated via colorize
                imagefilter($image, IMG_FILTER_COLORIZE, 0, 0, 0, ($value - 50) / 100);
                break;
            case 'vintage':
                imagefilter($image, IMG_FILTER_SEPIA);
                break;
            case 'black_white':
                imagefilter($image, IMG_FILTER_GRAYSCALE);
                break;
            case 'sepia':
                imagefilter($image, IMG_FILTER_SEPIA);
                break;
        }
        
        $file_info = pathinfo($photo_path);
        $new_file_path = $file_info['dirname'] . '/' . $file_info['filename'] . '_' . $filter_type . '.' . $file_info['extension'];
        imagejpeg($image, $new_file_path, 90);
        
        imagedestroy($image);
        return $new_file_path;
    }
    
    public static function generatePDF($photobook_id, $photos) {
        require_once 'vendor/autoload.php'; // Use TCPDF or similar library
        $pdf = new \TCPDF();
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('PixelMemories');
        $pdf->SetTitle('Photobook');
        $pdf->AddPage();
        
        foreach ($photos as $photo) {
            $pdf->Image($photo['file_path'], 10, 10, 190);
            if ($photo['caption']) {
                $pdf->SetXY(10, 10);
                $pdf->Write(0, $photo['caption']);
            }
            $pdf->AddPage();
        }
        
        $output_path = 'uploads/photobooks/photobook_' . $photobook_id . '.pdf';
        $pdf->Output($output_path, 'F');
        return $output_path;
    }
}
?>