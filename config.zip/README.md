# photobook-pixelMemories
A dynamic web application for creating, editing, and printing photobooks. Features include drag-and-drop photo editing, frame and filter application, PDF downloading, and a user-friendly gallery. Built with PHP, MySQL, Bootstrap, and jQuery for a seamless user experience.
